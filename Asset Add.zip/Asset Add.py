bl_info = {
    "name": "Asset Libraries Manager",
    "author": "Abdulrahman Baggash",
    "version": (1, 4),
    "blender": (4, 0, 0),
    "location": "Preferences > File Paths",
    "description": "Easily manage and add folders as asset libraries",
    "category": "System",
}


# Copy https://woow3d.com/ 
# 2025 February 12, 09:06 PM 
# CG & Dev Abdulrahman Baggash
#Update Script to addon 2025 oct 25
#https://github.com/woow3d/Asset-Library/tree/main


import os
import bpy
from bpy.types import Operator, Panel
from bpy.props import StringProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper


# ------------------------------------------------------------------------
#   Add Asset Libraries Operator
# ------------------------------------------------------------------------
class ASSET_OT_add_asset_libraries(Operator, ImportHelper):
    """Add all folders inside a selected directory as asset libraries"""
    bl_idname = "asset.add_asset_libraries"
    bl_label = "Add Asset Libraries"
    bl_options = {'REGISTER'}

    directory: StringProperty(
        name="Directory",
        description="Select folder containing subfolders for libraries",
        maxlen=1024,
        subtype='DIR_PATH'
    )

    replace_existing: BoolProperty(
        name="Replace Existing",
        description="Clear all existing libraries before adding new ones",
        default=False
    )

    filename_ext = ""
    use_filter_folder = True

    def execute(self, context):
        root_path = self.directory.strip()

        if not root_path:
            self.report({'ERROR'}, "❌ No folder selected! Please choose a folder.")
            return {'CANCELLED'}

        if not os.path.exists(root_path):
            self.report({'ERROR'}, "❌ The selected path does not exist.")
            return {'CANCELLED'}

        prefs = context.preferences.filepaths
        if self.replace_existing:
            count = len(prefs.asset_libraries)
            prefs.asset_libraries.clear()
            print(f"🧹 Cleared {count} existing libraries.")

        print(f"📁 Selected Root Folder: {root_path}")

        existing_names = [lib.name for lib in prefs.asset_libraries]
        added_count = 0

        for folder_name in sorted(os.listdir(root_path)):
            folder_path = os.path.join(root_path, folder_name)
            if os.path.isdir(folder_path):
                if folder_name not in existing_names:
                    prefs.asset_libraries.new(name=folder_name, directory=folder_path)
                    added_count += 1
                    print(f"✅ Added: {folder_name}")
                else:
                    print(f"⚠️ Library '{folder_name}' already exists.")

        if added_count > 0:
            bpy.ops.wm.save_userpref()
            self.report({'INFO'}, f"✅ Added {added_count} new libraries.")
        else:
            self.report({'INFO'}, "📦 No new libraries added.")

        return {'FINISHED'}


# ------------------------------------------------------------------------
#   Remove All Libraries Operator
# ------------------------------------------------------------------------
class ASSET_OT_remove_all_libraries(Operator):
    """Remove all asset libraries"""
    bl_idname = "asset.remove_all_libraries"
    bl_label = "Remove All Libraries"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = context.preferences.filepaths
        count = len(prefs.asset_libraries)

        if count == 0:
            self.report({'INFO'}, "📭 No libraries to remove.")
            return {'CANCELLED'}

        prefs.asset_libraries.clear()
        bpy.ops.wm.save_userpref()
        self.report({'INFO'}, f"🗑️ Removed {count} libraries.")
        return {'FINISHED'}


# ------------------------------------------------------------------------
#   Open Website Operator
# ------------------------------------------------------------------------
class ASSET_OT_open_website(Operator):
    """Open developer website"""
    bl_idname = "asset.open_website"
    bl_label = "Open Website"

    def execute(self, context):
        bpy.ops.wm.url_open(url="https://woow3d.com/add-ons")
        return {'FINISHED'}


# ------------------------------------------------------------------------
#   Main Panel
# ------------------------------------------------------------------------
class ASSET_PT_panel(Panel):
    """Asset Libraries Manager Panel"""
    bl_label = "📦 Asset Libraries Manager"
    bl_idname = "ASSET_PT_panel"
    bl_space_type = 'PREFERENCES'
    bl_region_type = 'WINDOW'
    bl_context = "file_paths"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        # ----------------------------------------------------------------
        # 🧾 Addon Info
        # ----------------------------------------------------------------
        info_box = layout.box()
        info_box.label(text="🧾 Addon Information", icon='INFO')
        col = info_box.column(align=True)
        col.label(text="👨‍💻 Developer: Abdulrahman Baggash")
        col.label(text="🌐 Website:")
        col.operator("asset.open_website", text="woow3d.com", icon='URL')
        col.label(text="📅 Version: 1.4 (2025)")
        col.separator()

        # ----------------------------------------------------------------
        # ⚙️ Management Section
        # ----------------------------------------------------------------
        manage_box = layout.box()
        manage_box.label(text="⚙️ Manage Libraries", icon='SETTINGS')

        col = manage_box.column(align=True)
        col.operator("asset.add_asset_libraries", text="➕ Add Asset Libraries", icon='ADD')
        col.operator("asset.remove_all_libraries", text="🗑️ Remove All Libraries", icon='TRASH')

        # ----------------------------------------------------------------
        # 📚 Current Libraries
        # ----------------------------------------------------------------
        libs_box = layout.box()
        libs_box.label(text="📚 Current Asset Libraries", icon='ASSET_MANAGER')

        prefs = context.preferences.filepaths
        if prefs.asset_libraries:
            for lib in prefs.asset_libraries:
                row = libs_box.row()
                row.label(text=f"📁 {lib.name}")
                row.label(text=f"📍 {lib.path}")
        else:
            libs_box.label(text="📭 No asset libraries added.", icon='INFO')


# ------------------------------------------------------------------------
#   Registration
# ------------------------------------------------------------------------
classes = (
    ASSET_OT_add_asset_libraries,
    ASSET_OT_remove_all_libraries,
    ASSET_OT_open_website,
    ASSET_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    print("✅ Asset Libraries Manager v1.4 Loaded")


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    print("❎ Asset Libraries Manager Unloaded")


if __name__ == "__main__":
    register()
